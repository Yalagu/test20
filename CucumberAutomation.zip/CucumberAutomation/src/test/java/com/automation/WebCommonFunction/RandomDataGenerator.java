package com.automation.WebCommonFunction;

import java.util.GregorianCalendar;
import java.util.Random;
import java.util.UUID;

public class RandomDataGenerator {
    public RandomDataGenerator() {
    }

    public static Integer getRandomNumber(int min, int max) {
        int number = (int) (Math.random() * (double) (max - min + 1)) + min;
        return number;
    }

    public static String getUniqueString() {
        UUID uuid = UUID.randomUUID();
        String string = uuid.toString().replace("-", "");
        return string;
    }

    public static String getUUID() {
        UUID uuid = UUID.randomUUID();
        String string = uuid.toString();
        return string;
    }

    public static String getRandomString(int length) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < length; ++i) {
            char c = (char) ((int) (Math.random() * 26.0 + 65.0));
            sb.append(c);
        }

        return sb.toString().toLowerCase();
    }

    public static String generateSpecialCharacterString(int length) {
        Random r = new Random();
        char[] choices = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567890$#@)!%&*(_+=/~`".toCharArray();
        StringBuilder specialString = new StringBuilder(length);

        for (int i = 0; i < length; ++i) {
            specialString.append(choices[r.nextInt(choices.length)]);
        }

        return specialString.toString();
    }
}
